async function handler({
  action,
  roomCode,
  password,
  message,
  username,
  userId,
}) {
  try {
    if (action === "create_private_channel") {
      if (!roomCode || !password) {
        return { error: "Room code and password required" };
      }

      const existingRoom = await sql(
        "SELECT room_code FROM private_channels WHERE room_code = $1",
        [roomCode]
      );
      if (existingRoom.length > 0) {
        return { error: "Room already exists" };
      }

      await sql(
        "INSERT INTO private_channels (room_code, password_hash) VALUES ($1, $2)",
        [roomCode, password]
      );

      return { success: true, message: "Private channel created" };
    }

    if (action === "list_public_channels") {
      const publicChannels = await sql(`
        SELECT DISTINCT room_code, COUNT(*) as message_count 
        FROM messages 
        WHERE room_code NOT IN (SELECT room_code FROM private_channels)
        GROUP BY room_code
        ORDER BY message_count DESC
      `);

      return { channels: publicChannels };
    }

    if (action === "list_private_channels") {
      const privateChannels = await sql(`
        SELECT room_code, created_at 
        FROM private_channels 
        ORDER BY created_at DESC
      `);

      return { channels: privateChannels };
    }

    if (action === "verify_channel_password") {
      if (!roomCode || !password) {
        return { error: "Room code and password required" };
      }

      const channel = await sql(
        "SELECT password_hash FROM private_channels WHERE room_code = $1",
        [roomCode]
      );

      if (channel.length === 0) {
        return { error: "Channel not found" };
      }

      if (channel[0].password_hash !== password) {
        return { error: "Invalid password" };
      }

      return { success: true };
    }

    if (action === "send_message") {
      if (!roomCode || !message || !username || !userId) {
        return { error: "Missing required fields" };
      }

      const bannedCheck = await sql(
        "SELECT username FROM banned_users WHERE username = $1",
        [username]
      );
      if (bannedCheck.length > 0) {
        return { error: "User is banned" };
      }

      const isPrivate = await sql(
        "SELECT room_code FROM private_channels WHERE room_code = $1",
        [roomCode]
      );
      if (isPrivate.length > 0 && !password) {
        return { error: "Password required for private channel" };
      }

      if (isPrivate.length > 0) {
        const verification = await sql(
          "SELECT password_hash FROM private_channels WHERE room_code = $1 AND password_hash = $2",
          [roomCode, password]
        );
        if (verification.length === 0) {
          return { error: "Invalid channel password" };
        }
      }

      await sql(
        `
        INSERT INTO messages (user_id, username, content, room_code) 
        VALUES ($1, $2, $3, $4)
      `,
        [userId, username, message, roomCode]
      );

      return { success: true };
    }

    if (action === "get_messages") {
      if (!roomCode) {
        return { error: "Room code required" };
      }

      const isPrivate = await sql(
        "SELECT room_code FROM private_channels WHERE room_code = $1",
        [roomCode]
      );
      if (isPrivate.length > 0 && !password) {
        return { error: "Password required for private channel" };
      }

      if (isPrivate.length > 0) {
        const verification = await sql(
          "SELECT password_hash FROM private_channels WHERE room_code = $1 AND password_hash = $2",
          [roomCode, password]
        );
        if (verification.length === 0) {
          return { error: "Invalid channel password" };
        }
      }

      const messages = await sql(
        `
        SELECT id, user_id, username, content, created_at, is_admin
        FROM messages 
        WHERE room_code = $1 
        ORDER BY created_at DESC 
        LIMIT 100
      `,
        [roomCode]
      );

      return { messages };
    }

    return { error: "Invalid action" };
  } catch (error) {
    console.error("Chat error:", error);
    return { error: "Internal server error" };
  }
}