async function handler({ action, username, password }) {
  if (action === "admin_login") {
    // Simple admin authentication
    const adminAccount = await sql`
      SELECT * FROM admin_accounts 
      WHERE username = ${username} 
      AND password_hash = ${password}
    `;

    return {
      success: adminAccount.length > 0,
    };
  }

  return { error: "Invalid action" };
}