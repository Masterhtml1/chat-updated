async function handler({
  action,
  username,
  password,
  userToBan,
  roomCode,
  reason,
  bannedBy,
}) {
  if (action === "login") {
    const admins = await sql`
      SELECT * FROM admin_accounts 
      WHERE username = ${username} 
      AND password_hash = ${password}
      LIMIT 1
    `;
    return { success: admins.length > 0 };
  }

  if (action === "list_bans") {
    const bans = await sql`
      SELECT username, banned_at, banned_by, room_code, reason 
      FROM banned_users 
      ORDER BY banned_at DESC
    `;
    return { bans };
  }

  if (action === "ban") {
    if (!userToBan || !bannedBy) {
      return { error: "Missing required fields" };
    }

    await sql`
      INSERT INTO banned_users (username, banned_by, room_code, reason)
      VALUES (${userToBan}, ${bannedBy}, ${roomCode}, ${reason})
    `;
    return { success: true };
  }

  if (action === "reset_room") {
    if (!roomCode) {
      return { error: "Room code required" };
    }

    await sql`
      DELETE FROM messages 
      WHERE room_code = ${roomCode}
    `;
    return { success: true };
  }

  return { error: "Invalid action" };
}