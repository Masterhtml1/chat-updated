"use client";
import React from "react";

function MainComponent() {
  const [bannedUsers, setBannedUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [userStats, setUserStats] = useState([]);
  const [roomStats, setRoomStats] = useState([]);
  const [error, setError] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState("banned");
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [showClearAllWarning, setShowClearAllWarning] = useState(false);
  const [reportedMessages, setReportedMessages] = useState([]);

  useEffect(() => {
    if (isLoggedIn) {
      fetchAllData();
      const interval = setInterval(fetchAllData, 5000);
      return () => clearInterval(interval);
    }
  }, [isLoggedIn]);

  const fetchAllData = async () => {
    try {
      await Promise.all([
        fetchBannedUsers(),
        fetchMessages(),
        fetchUserStats(),
        fetchRoomStats(),
        fetchReportedMessages(),
      ]);
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Failed to load some data");
    }
  };

  const fetchBannedUsers = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_banned_users",
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.bannedUsers) {
        setBannedUsers(data.bannedUsers);
      }
    } catch (err) {
      console.error("Error fetching banned users:", err);
      setError("Failed to load banned users list");
    }
  };

  const unbanUser = async (bannedUsername) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "unban",
          username: bannedUsername,
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      await fetchBannedUsers();
      setError(`User ${bannedUsername} has been unbanned`);
    } catch (err) {
      console.error("Error unbanning user:", err);
      setError("Failed to unban user");
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_messages",
          adminUsername: username,
          roomCode: selectedRoom,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setMessages(data.messages || []);
      setError(null);
    } catch (err) {
      console.error("Error fetching messages:", err);
      setError("Failed to load messages. " + err.message);
    }
  };

  const fetchUserStats = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_user_stats",
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.userStats) {
        setUserStats(data.userStats);
      }
    } catch (err) {
      console.error("Error fetching user stats:", err);
      setError("Failed to load user statistics");
    }
  };

  const fetchRoomStats = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_room_stats",
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.roomStats) {
        setRoomStats(data.roomStats);
      }
    } catch (err) {
      console.error("Error fetching room stats:", err);
      setError("Failed to load room statistics");
    }
  };

  const deleteMessage = async (messageId) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "delete_message",
          messageId,
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      await fetchMessages();
      setError("Message deleted successfully");
    } catch (err) {
      console.error("Error deleting message:", err);
      setError("Failed to delete message");
    }
  };

  const clearRoomHistory = async (roomCode) => {
    if (
      !confirm(
        `Are you sure you want to clear all messages in room ${roomCode}?`
      )
    ) {
      return;
    }

    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "clear_room",
          roomCode,
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      await fetchAllData();
      setError(`Room ${roomCode} history cleared`);
    } catch (err) {
      console.error("Error clearing room:", err);
      setError("Failed to clear room history");
    }
  };

  const clearAllHistory = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "clear_all_history",
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      await fetchAllData();
      setShowClearAllWarning(false);
      setError("All chat history has been cleared");
    } catch (err) {
      console.error("Error clearing all history:", err);
      setError("Failed to clear chat history");
    }
  };

  const hashPassword = (str) => {
    function MD5(d) {
      var r = M(V(Y(X(d), 8 * d.length)));
      return r.toLowerCase();
    }
    function M(d) {
      for (var _, m = "0123456789ABCDEF", f = "", r = 0; r < d.length; r++)
        (_ = d.charCodeAt(r)),
          (f += m.charAt((_ >>> 4) & 15) + m.charAt(15 & _));
      return f;
    }
    function X(d) {
      for (var _ = Array(d.length >> 2), m = 0; m < _.length; m++) _[m] = 0;
      for (m = 0; m < 8 * d.length; m += 8)
        _[m >> 5] |= (255 & d.charCodeAt(m / 8)) << m % 32;
      return _;
    }
    function V(d) {
      for (var _ = "", m = 0; m < 32 * d.length; m += 8)
        _ += String.fromCharCode((d[m >> 5] >>> m % 32) & 255);
      return _;
    }
    function Y(d, _) {
      (d[_ >> 5] |= 128 << _ % 32), (d[14 + (((_ + 64) >>> 9) << 4)] = _);
      for (
        var m = 1732584193,
          f = -271733879,
          r = -1732584194,
          i = 271733878,
          n = 0;
        n < d.length;
        n += 16
      ) {
        var h = m,
          t = f,
          g = r,
          e = i;
        (f = md5_ii(
          (f = md5_ii(
            (f = md5_ii(
              (f = md5_ii(
                (f = md5_hh(
                  (f = md5_hh(
                    (f = md5_hh(
                      (f = md5_hh(
                        (f = md5_gg(
                          (f = md5_gg(
                            (f = md5_gg(
                              (f = md5_gg(
                                (f = md5_ff(
                                  (f = md5_ff(
                                    (f = md5_ff(
                                      (f = md5_ff(
                                        f,
                                        (r = md5_ff(
                                          r,
                                          (i = md5_ff(
                                            i,
                                            (m = md5_ff(
                                              m,
                                              f,
                                              r,
                                              i,
                                              d[n + 0],
                                              7,
                                              -680876936
                                            )),
                                            f,
                                            r,
                                            d[n + 1],
                                            12,
                                            -389564586
                                          )),
                                          m,
                                          f,
                                          d[n + 2],
                                          17,
                                          606105819
                                        )),
                                        i,
                                        m,
                                        d[n + 3],
                                        22,
                                        -1044525330
                                      )),
                                      (r = md5_ff(
                                        r,
                                        (i = md5_ff(
                                          i,
                                          (m = md5_ff(
                                            m,
                                            f,
                                            r,
                                            i,
                                            d[n + 4],
                                            7,
                                            -176418897
                                          )),
                                          f,
                                          r,
                                          d[n + 5],
                                          12,
                                          1200080426
                                        )),
                                        m,
                                        f,
                                        d[n + 6],
                                        17,
                                        -1473231341
                                      )),
                                      i,
                                      m,
                                      d[n + 7],
                                      22,
                                      -45705983
                                    )),
                                    (r = md5_ff(
                                      r,
                                      (i = md5_ff(
                                        i,
                                        (m = md5_ff(
                                          m,
                                          f,
                                          r,
                                          i,
                                          d[n + 8],
                                          7,
                                          1770035416
                                        )),
                                        f,
                                        r,
                                        d[n + 9],
                                        12,
                                        -1958414417
                                      )),
                                      m,
                                      f,
                                      d[n + 10],
                                      17,
                                      -42063
                                    )),
                                    i,
                                    m,
                                    d[n + 11],
                                    22,
                                    -1990404162
                                  )),
                                  (r = md5_ff(
                                    r,
                                    (i = md5_ff(
                                      i,
                                      (m = md5_ff(
                                        m,
                                        f,
                                        r,
                                        i,
                                        d[n + 12],
                                        7,
                                        1804603682
                                      )),
                                      f,
                                      r,
                                      d[n + 13],
                                      12,
                                      -40341101
                                    )),
                                    m,
                                    f,
                                    d[n + 14],
                                    17,
                                    -1502002290
                                  )),
                                  i,
                                  m,
                                  d[n + 15],
                                  22,
                                  1236535329
                                )),
                                (r = md5_gg(
                                  r,
                                  (i = md5_gg(
                                    i,
                                    (m = md5_gg(
                                      m,
                                      f,
                                      r,
                                      i,
                                      d[n + 1],
                                      5,
                                      -165796510
                                    )),
                                    f,
                                    r,
                                    d[n + 6],
                                    9,
                                    -1069501632
                                  )),
                                  m,
                                  f,
                                  d[n + 11],
                                  14,
                                  643717713
                                )),
                                i,
                                m,
                                d[n + 0],
                                20,
                                -373897302
                              )),
                              (r = md5_gg(
                                r,
                                (i = md5_gg(
                                  i,
                                  (m = md5_gg(
                                    m,
                                    f,
                                    r,
                                    i,
                                    d[n + 5],
                                    5,
                                    -701558691
                                  )),
                                  f,
                                  r,
                                  d[n + 10],
                                  9,
                                  38016083
                                )),
                                m,
                                f,
                                d[n + 15],
                                14,
                                -660478335
                              )),
                              i,
                              m,
                              d[n + 4],
                              20,
                              -405537848
                            )),
                            (r = md5_gg(
                              r,
                              (i = md5_gg(
                                i,
                                (m = md5_gg(
                                  m,
                                  f,
                                  r,
                                  i,
                                  d[n + 9],
                                  5,
                                  568446438
                                )),
                                f,
                                r,
                                d[n + 14],
                                9,
                                -1019803690
                              )),
                              m,
                              f,
                              d[n + 3],
                              14,
                              -187363961
                            )),
                            i,
                            m,
                            d[n + 8],
                            20,
                            1163531501
                          )),
                          (r = md5_gg(
                            r,
                            (i = md5_gg(
                              i,
                              (m = md5_gg(
                                m,
                                f,
                                r,
                                i,
                                d[n + 13],
                                5,
                                -1444681467
                              )),
                              f,
                              r,
                              d[n + 2],
                              9,
                              -51403784
                            )),
                            m,
                            f,
                            d[n + 7],
                            14,
                            1735328473
                          )),
                          i,
                          m,
                          d[n + 12],
                          20,
                          -1926607734
                        )),
                        (r = md5_hh(
                          r,
                          (i = md5_hh(
                            i,
                            (m = md5_hh(m, f, r, i, d[n + 5], 4, -378558)),
                            f,
                            r,
                            d[n + 8],
                            11,
                            -2022574463
                          )),
                          m,
                          f,
                          d[n + 11],
                          16,
                          1839030562
                        )),
                        i,
                        m,
                        d[n + 14],
                        23,
                        -35309556
                      )),
                      (r = md5_hh(
                        r,
                        (i = md5_hh(
                          i,
                          (m = md5_hh(m, f, r, i, d[n + 1], 4, -1530992060)),
                          f,
                          r,
                          d[n + 4],
                          11,
                          1272893353
                        )),
                        m,
                        f,
                        d[n + 7],
                        16,
                        -155497632
                      )),
                      i,
                      m,
                      d[n + 10],
                      23,
                      -1094730640
                    )),
                    (r = md5_hh(
                      r,
                      (i = md5_hh(
                        i,
                        (m = md5_hh(m, f, r, i, d[n + 13], 4, 681279174)),
                        f,
                        r,
                        d[n + 0],
                        11,
                        -358537222
                      )),
                      m,
                      f,
                      d[n + 3],
                      16,
                      -722521979
                    )),
                    i,
                    m,
                    d[n + 6],
                    23,
                    76029189
                  )),
                  (r = md5_hh(
                    r,
                    (i = md5_hh(
                      i,
                      (m = md5_hh(m, f, r, i, d[n + 9], 4, -640364487)),
                      f,
                      r,
                      d[n + 12],
                      11,
                      -421815835
                    )),
                    m,
                    f,
                    d[n + 15],
                    16,
                    530742520
                  )),
                  i,
                  m,
                  d[n + 2],
                  23,
                  -995338651
                )),
                (r = md5_ii(
                  r,
                  (i = md5_ii(
                    i,
                    (m = md5_ii(m, f, r, i, d[n + 0], 6, -198630844)),
                    f,
                    r,
                    d[n + 7],
                    10,
                    1126891415
                  )),
                  m,
                  f,
                  d[n + 14],
                  15,
                  -1416354905
                )),
                i,
                m,
                d[n + 5],
                21,
                -57434055
              )),
              (r = md5_ii(
                r,
                (i = md5_ii(
                  i,
                  (m = md5_ii(m, f, r, i, d[n + 12], 6, 1700485571)),
                  f,
                  r,
                  d[n + 3],
                  10,
                  -1894986606
                )),
                m,
                f,
                d[n + 10],
                15,
                -1051523
              )),
              i,
              m,
              d[n + 1],
              21,
              -2054922799
            )),
            (r = md5_ii(
              r,
              (i = md5_ii(
                i,
                (m = md5_ii(m, f, r, i, d[n + 8], 6, 1873313359)),
                f,
                r,
                d[n + 15],
                10,
                -30611744
              )),
              m,
              f,
              d[n + 6],
              15,
              -1560198380
            )),
            i,
            m,
            d[n + 13],
            21,
            1309151649
          )),
          (r = md5_ii(
            r,
            (i = md5_ii(
              i,
              (m = md5_ii(m, f, r, i, d[n + 4], 6, -145523070)),
              f,
              r,
              d[n + 11],
              10,
              -1120210379
            )),
            m,
            f,
            d[n + 2],
            15,
            718787259
          )),
          i,
          m,
          d[n + 9],
          21,
          -343485551
        )),
          (m = safe_add(m, h)),
          (f = safe_add(f, t)),
          (r = safe_add(r, g)),
          (i = safe_add(i, e));
      }
      return Array(m, f, r, i);
    }
    function md5_cmn(d, _, m, f, r, i) {
      return safe_add(bit_rol(safe_add(safe_add(_, d), safe_add(f, i)), r), m);
    }
    function md5_ff(d, _, m, f, r, i, n) {
      return md5_cmn((_ & m) | (~_ & f), d, _, r, i, n);
    }
    function md5_gg(d, _, m, f, r, i, n) {
      return md5_cmn((_ & f) | (m & ~f), d, _, r, i, n);
    }
    function md5_hh(d, _, m, f, r, i, n) {
      return md5_cmn(_ ^ m ^ f, d, _, r, i, n);
    }
    function md5_ii(d, _, m, f, r, i, n) {
      return md5_cmn(m ^ (_ | ~f), d, _, r, i, n);
    }
    function safe_add(d, _) {
      var m = (65535 & d) + (65535 & _);
      return (((d >> 16) + (_ >> 16) + (m >> 16)) << 16) | (65535 & m);
    }
    function bit_rol(d, _) {
      return (d << _) | (d >>> (32 - _));
    }
    return MD5(str);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    if (username !== "LeBron") {
      setError("Invalid username or password");
      return;
    }

    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "verify",
          username: username,
          password: hashPassword(password),
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        setError(data.error);
        return;
      }

      setIsLoggedIn(true);
      setError(null);
    } catch (err) {
      console.error("Login error:", err);
      setError("Failed to log in. Please try again.");
    }
  };

  const fetchReportedMessages = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_reported_messages",
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setReportedMessages(data.reportedMessages || []);
      setError(null);
    } catch (err) {
      console.error("Error fetching reported messages:", err);
      setError("Failed to load reported messages. " + err.message);
    }
  };

  const resolveReport = async (messageId) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "resolve_report",
          messageId,
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      await fetchReportedMessages();
      setError("Report resolved successfully");
    } catch (err) {
      console.error("Error resolving report:", err);
      setError("Failed to resolve report");
    }
  };

  const refreshCurrentTab = async () => {
    try {
      setError(null);
      switch (activeTab) {
        case "banned":
          await fetchBannedUsers();
          break;
        case "messages":
          await fetchMessages();
          break;
        case "reports":
          await fetchReportedMessages();
          break;
        case "users":
          await fetchUserStats();
          break;
        case "rooms":
          await fetchRoomStats();
          break;
      }
    } catch (err) {
      console.error("Error refreshing data:", err);
      setError("Failed to refresh data");
    }
  };

  const renderTabs = () => (
    <div className="mb-6">
      <div className="border-b border-gray-200">
        <div className="flex justify-between items-center">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab("banned")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "banned"
                  ? "border-[#FF69B4] text-[#FF69B4]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Banned Users
            </button>
            <button
              onClick={() => setActiveTab("messages")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "messages"
                  ? "border-[#FF69B4] text-[#FF69B4]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Messages
            </button>
            <button
              onClick={() => setActiveTab("reports")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "reports"
                  ? "border-[#FF69B4] text-[#FF69B4]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Reports
            </button>
            <button
              onClick={() => setActiveTab("users")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "users"
                  ? "border-[#FF69B4] text-[#FF69B4]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              User Stats
            </button>
            <button
              onClick={() => setActiveTab("rooms")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "rooms"
                  ? "border-[#FF69B4] text-[#FF69B4]"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Room Stats
            </button>
          </nav>
          <button
            onClick={refreshCurrentTab}
            className="flex items-center space-x-1 px-3 py-2 bg-white text-[#FF69B4] border border-[#FF69B4] rounded hover:bg-[#FF69B4] hover:text-white transition duration-200"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
              />
            </svg>
            <span>Refresh</span>
          </button>
        </div>
      </div>
    </div>
  );

  const renderBannedUsers = () => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Banned Users</h2>
      {bannedUsers.length === 0 ? (
        <p className="text-gray-600">No users are currently banned</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Username
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Banned At
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {bannedUsers.map((user) => (
                <tr key={user.username}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.username}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {new Date(user.banned_at).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => unbanUser(user.username)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Unban
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderMessages = () => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Messages</h2>
        <select
          value={selectedRoom || ""}
          onChange={(e) => setSelectedRoom(e.target.value || null)}
          className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
        >
          <option value="">All Rooms</option>
          {roomStats.map((room) => (
            <option key={room.room_code} value={room.room_code}>
              {room.room_code}
            </option>
          ))}
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Room
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Message
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {messages.map((message) => (
              <tr key={message.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(message.created_at).toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {message.room_code}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {message.username}
                </td>
                <td className="px-6 py-4">{message.content}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    onClick={() => deleteMessage(message.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderUserStats = () => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">User Statistics</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Username
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Messages
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Active Rooms
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                First Message
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Message
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {userStats.map((stat) => (
              <tr key={stat.username}>
                <td className="px-6 py-4 whitespace-nowrap">{stat.username}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {stat.message_count}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {stat.rooms_active_in}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(stat.first_message).toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(stat.last_message).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderRoomStats = () => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Room Statistics</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Room
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Messages
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Unique Users
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                First Message
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Message
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {roomStats.map((stat) => (
              <tr key={stat.room_code}>
                <td className="px-6 py-4 whitespace-nowrap">
                  {stat.room_code}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {stat.message_count}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {stat.unique_users}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(stat.first_message).toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(stat.last_message).toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    onClick={() => clearRoomHistory(stat.room_code)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Clear History
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Reported Messages</h2>
      {reportedMessages.length === 0 ? (
        <p className="text-gray-600">No pending reports</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Message
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Author
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Reported By
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reportedMessages.map((report) => (
                <tr key={`${report.message_id}-${report.reported_by}`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {new Date(report.reported_at).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">{report.content}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {report.username}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {report.reported_by}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => resolveReport(report.message_id)}
                        className="text-green-600 hover:text-green-900"
                      >
                        Resolve
                      </button>
                      <button
                        onClick={() => deleteMessage(report.message_id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                      <button
                        onClick={() => banUser(report.username)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Ban User
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderWarningModal = () => {
    if (!showClearAllWarning) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 max-w-lg w-full mx-4">
          <h2 className="text-2xl font-bold text-red-600 mb-4">
            ⚠️ Warning: Destructive Action
          </h2>
          <div className="space-y-4">
            <p className="text-gray-700">
              You are about to delete{" "}
              <span className="font-bold">ALL messages</span> from{" "}
              <span className="font-bold">ALL rooms</span>.
            </p>
            <p className="text-gray-700">This action:</p>
            <ul className="list-disc pl-5 text-gray-700">
              <li>Cannot be undone</li>
              <li>Will delete all messages from all rooms</li>
              <li>Will affect all users</li>
              <li>Will keep user accounts and room structures intact</li>
            </ul>
            <p className="text-gray-700 font-bold">
              Are you absolutely sure you want to proceed?
            </p>
          </div>
          <div className="mt-8 flex space-x-4">
            <button
              onClick={() => setShowClearAllWarning(false)}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition duration-200"
            >
              Cancel
            </button>
            <button
              onClick={clearAllHistory}
              className="flex-1 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition duration-200"
            >
              Yes, Clear All History
            </button>
          </div>
        </div>
      </div>
    );
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-white p-8">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-2xl font-bold text-[#FF69B4] mb-6">
            Admin Login
          </h1>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="username">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                required
              />
            </div>
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                required
              />
            </div>
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded">
                {error}
              </div>
            )}
            <button
              type="submit"
              className="w-full bg-[#FF69B4] text-white py-2 rounded hover:bg-[#FF1493] transition duration-200"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-[#FF69B4]">Admin Dashboard</h1>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowClearAllWarning(true)}
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition duration-200"
            >
              Clear All Server History
            </button>
            <button
              onClick={() => setIsLoggedIn(false)}
              className="text-gray-600 hover:text-gray-900"
            >
              Logout
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded mb-6 flex justify-between items-center">
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="text-red-700 hover:text-red-900 ml-2"
            >
              ✕
            </button>
          </div>
        )}

        {renderTabs()}

        {activeTab === "banned" && renderBannedUsers()}
        {activeTab === "messages" && renderMessages()}
        {activeTab === "reports" && renderReports()}
        {activeTab === "users" && renderUserStats()}
        {activeTab === "rooms" && renderRoomStats()}

        {renderWarningModal()}
      </div>
    </div>
  );
}

export default MainComponent;