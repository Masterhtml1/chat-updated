"use client";
import React from "react";

function MainComponent() {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [error, setError] = useState(null);
  const [nickname, setNickname] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [isJoined, setIsJoined] = useState(false);
  const [password, setPassword] = useState("");
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState(null);
  const [editMessageContent, setEditMessageContent] = useState("");
  const [filteredWords] = useState([
    "drugs",
    "illegal",
    "weapon",
    "stolen",
    "porn",
    "xxx",
    "nsfw",
    "fuck",
    "shit",
    "ass",
    "bitch",
    "nazi",
    "hate",
    "kill",
  ]);
  const [lastMessageId, setLastMessageId] = useState(0);

  useEffect(() => {
    if (isJoined) {
      fetchMessages();
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [isJoined]);

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "get_messages",
          roomCode,
          lastMessageId,
        }),
      });

      if (!response.ok) {
        if (response.status === 429) {
          return;
        }
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data && data.messages) {
        if (data.messages.length > 0) {
          setMessages((prevMessages) => {
            const newMessages = [...prevMessages];
            data.messages.forEach((message) => {
              if (!newMessages.find((m) => m.id === message.id)) {
                newMessages.push(message);
              }
            });
            newMessages.sort(
              (a, b) => new Date(a.created_at) - new Date(b.created_at)
            );
            if (newMessages.length > 0) {
              setLastMessageId(Math.max(...newMessages.map((m) => m.id)));
            }
            return newMessages;
          });
        }
        setError(null);
      } else {
        throw new Error("Invalid message format received");
      }
    } catch (err) {
      console.error("Error fetching messages:", err);
      if (!err.message.includes("429")) {
        setError("Unable to load messages. Please try again later.");
      }
    }
  };

  const checkMessageContent = (message) => {
    const lowerMessage = message.toLowerCase();

    const foundWord = filteredWords.find((word) => lowerMessage.includes(word));
    if (foundWord) {
      setError(`Message blocked: Contains inappropriate content`);
      return false;
    }

    const upperCaseCount = (message.match(/[A-Z]/g) || []).length;
    if (upperCaseCount > message.length * 0.7 && message.length > 5) {
      setError("Please don't use excessive capitalization");
      return false;
    }

    if (message.length > 500) {
      setError("Message is too long (maximum 500 characters)");
      return false;
    }

    const repeatedChars = message.match(/(.)\1{4,}/g);
    if (repeatedChars) {
      setError("Please avoid repeating characters");
      return false;
    }

    return true;
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    if (!checkMessageContent(newMessage)) {
      return;
    }

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "send",
          content: newMessage.trim(),
          username: nickname,
          roomCode: roomCode,
          isAdmin: isAdmin,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      setNewMessage("");
      await fetchMessages();
      setError(null);
    } catch (err) {
      console.error("Error sending message:", err);
      setError("Failed to send message. Please try again.");
    }
  };

  const handleNicknameChange = (e) => {
    const newNickname = e.target.value;
    setNickname(newNickname);
    setShowPasswordInput(newNickname === "LeBron");
  };

  const handleJoinChat = async (e) => {
    e.preventDefault();
    if (!nickname.trim() || !roomCode.trim()) return;

    if (nickname === "LeBron") {
      try {
        const response = await fetch("/api/auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "verify",
            username: nickname,
            password: password,
          }),
        });

        if (!response.ok) {
          setError("Authentication failed");
          return;
        }

        const data = await response.json();
        console.log("Auth response:", data);

        if (data.error) {
          setError(data.error);
          return;
        }

        if (!data.success) {
          setError("Invalid credentials");
          return;
        }

        setIsAdmin(true);
      } catch (err) {
        console.error("Auth error:", err);
        setError("Authentication failed");
        return;
      }
    }

    setIsJoined(true);
  };

  const banUser = async (username) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "ban",
          username,
          adminUsername: nickname,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      setError(`User ${username} has been banned`);
      await fetchMessages();
    } catch (err) {
      console.error("Error banning user:", err);
      setError("Failed to ban user. Please try again.");
    }
  };

  const startEditMessage = (message) => {
    setEditingMessageId(message.id);
    setEditMessageContent(message.content);
  };

  const saveEditedMessage = async () => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "edit",
          messageId: editingMessageId,
          newContent: editMessageContent,
          adminUsername: nickname,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      setEditingMessageId(null);
      setEditMessageContent("");
      await fetchMessages();
    } catch (err) {
      console.error("Error editing message:", err);
      setError("Failed to edit message. Please try again.");
    }
  };

  const reportMessage = async (messageId) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "report",
          messageId,
          reportedBy: nickname,
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setError("Message reported to admins");
      setShowReportButton(null);
    } catch (err) {
      console.error("Error reporting message:", err);
      setError("Failed to report message. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <link
        rel="icon"
        href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='20' fill='%23FF69B4'/><circle cx='30' cy='50' r='8' fill='white'/><circle cx='50' cy='50' r='8' fill='white'/><circle cx='70' cy='50' r='8' fill='white'/></svg>"
      />

      {!isJoined ? (
        <div className="min-h-screen bg-white">
          <header className="bg-white border-b border-gray-200">
            <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h1 className="text-2xl font-bold text-[#FF69B4]">
                  Chat.Create
                </h1>
                <a
                  href="https://github.com/Masterhtml1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-gray-900"
                >
                  <svg
                    height="24"
                    width="24"
                    viewBox="0 0 16 16"
                    className="fill-current"
                  >
                    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z" />
                  </svg>
                </a>
              </div>
              <a
                href="#join-form"
                className="bg-[#FF69B4] text-white px-4 py-2 rounded hover:bg-[#FF1493]"
                onClick={(e) => {
                  e.preventDefault();
                  document
                    .querySelector("#join-form")
                    .scrollIntoView({ behavior: "smooth" });
                }}
              >
                Connect
              </a>
            </nav>
          </header>

          <main className="container mx-auto px-4 py-12">
            <div className="max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">
                  Chat with Friends, Family
                </h2>
                <p className="text-gray-600 mb-8">
                  Connect to channels and start chatting with the community
                </p>
              </div>

              <div id="join-form" className="bg-white shadow-lg rounded-lg p-8">
                <form onSubmit={handleJoinChat} className="space-y-6">
                  <div>
                    <label
                      className="block text-gray-700 mb-2"
                      htmlFor="nickname"
                    >
                      Nickname
                    </label>
                    <input
                      id="nickname"
                      name="nickname"
                      type="text"
                      value={nickname}
                      onChange={handleNicknameChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                      required
                    />
                  </div>

                  {showPasswordInput && (
                    <div>
                      <label
                        className="block text-gray-700 mb-2"
                        htmlFor="password"
                      >
                        Password
                      </label>
                      <input
                        id="password"
                        name="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                        required
                      />
                    </div>
                  )}

                  <div>
                    <label
                      className="block text-gray-700 mb-2"
                      htmlFor="channel"
                    >
                      Channel
                    </label>
                    <input
                      id="channel"
                      name="channel"
                      type="text"
                      value={roomCode}
                      onChange={(e) => setRoomCode(e.target.value)}
                      placeholder="#channel"
                      className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-[#FF69B4] text-white py-2 rounded hover:bg-[#FF1493] transition duration-200"
                  >
                    Join Channel
                  </button>
                </form>
              </div>
            </div>
          </main>
        </div>
      ) : (
        <div className="flex flex-col h-screen bg-white">
          <header className="bg-white border-b border-gray-200 py-3 px-4">
            <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h1 className="text-2xl font-bold text-[#FF69B4]">
                  Chat.Create
                </h1>
                <a
                  href="https://github.com/Masterhtml1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 hover:text-gray-900"
                >
                  <svg
                    height="24"
                    width="24"
                    viewBox="0 0 16 16"
                    className="fill-current"
                  >
                    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z" />
                  </svg>
                </a>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-gray-600">Connected as {nickname}</span>
                {isAdmin && (
                  <>
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      Admin
                    </span>
                    <a
                      href="/admin"
                      className="text-[#FF69B4] hover:text-[#FF1493] font-medium"
                    >
                      Dashboard
                    </a>
                  </>
                )}
                <button
                  onClick={() => setIsJoined(false)}
                  className="bg-[#FF69B4] text-white px-4 py-2 rounded hover:bg-[#FF1493]"
                >
                  Disconnect
                </button>
              </div>
            </nav>
          </header>

          {isJoined && (
            <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-white">
              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded flex justify-between items-center">
                  <span>{error}</span>
                  <button
                    onClick={() => setError(null)}
                    className="text-red-700 hover:text-red-900 ml-2"
                  >
                    ✕
                  </button>
                </div>
              )}
              {messages.map((message) => (
                <div key={message.id} className="flex items-start space-x-2">
                  <span className="text-gray-500 font-mono">
                    [{new Date(message.created_at).toLocaleTimeString()}]
                  </span>
                  <span
                    className={`font-medium ${
                      message.is_admin && message.username !== nickname
                        ? "text-green-600"
                        : "text-[#FF69B4]"
                    }`}
                  >
                    {message.is_admin && message.username !== nickname
                      ? "Admin"
                      : message.username}
                  </span>
                  <span>:</span>
                  <span className="text-gray-800">{message.content}</span>
                  {isAdmin && message.username !== nickname && (
                    <div className="flex space-x-2">
                      <button
                        onClick={() => startEditMessage(message)}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => banUser(message.username)}
                        className="text-red-500 hover:text-red-700"
                      >
                        Ban
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          <div className="border-t border-gray-200 p-4">
            <form onSubmit={sendMessage} className="flex space-x-2">
              <input
                type="text"
                name="newMessage"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
              />
              <button
                type="submit"
                className="bg-[#FF69B4] text-white px-6 py-2 rounded hover:bg-[#FF1493] transition duration-200"
              >
                Send
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default MainComponent;