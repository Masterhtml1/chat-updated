"use client";
import React from "react";

function MainComponent() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({ users: [], rooms: [] });
  const [bannedUsers, setBannedUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reportedMessages, setReportedMessages] = useState([]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchModData();
    }
  }, [isAuthenticated]);

  const fetchModData = async () => {
    try {
      setLoading(true);
      const [userStatsRes, roomStatsRes, bannedUsersRes, reportedMessagesRes] =
        await Promise.all([
          fetch("/api/admin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "get_user_stats" }),
          }),
          fetch("/api/admin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "get_room_stats" }),
          }),
          fetch("/api/admin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "get_banned_users" }),
          }),
          fetch("/api/admin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "get_reported_messages" }),
          }),
        ]);

      if (
        !userStatsRes.ok ||
        !roomStatsRes.ok ||
        !bannedUsersRes.ok ||
        !reportedMessagesRes.ok
      ) {
        throw new Error("Failed to fetch moderation data");
      }

      const [userStats, roomStats, bannedUsersData, reportedMessagesData] =
        await Promise.all([
          userStatsRes.json(),
          roomStatsRes.json(),
          bannedUsersRes.json(),
          reportedMessagesRes.json(),
        ]);

      setStats({
        users: userStats.userStats || [],
        rooms: roomStats.roomStats || [],
      });
      setBannedUsers(bannedUsersData.bannedUsers || []);
      setReportedMessages(reportedMessagesData.reportedMessages || []);
      setError(null);
    } catch (err) {
      console.error("Error fetching mod data:", err);
      setError("Failed to load moderation data");
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          password,
          action: "verify",
        }),
      });

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setIsAuthenticated(true);
      setError(null);
    } catch (err) {
      console.error("Login error:", err);
      setError("Invalid credentials");
    }
  };

  const handleUnban = async (username) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "unban",
          username,
          adminUsername: "lebron",
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to unban user");
      }

      await fetchModData();
      setError(null);
    } catch (err) {
      console.error("Unban error:", err);
      setError("Failed to unban user");
    }
  };

  const handleResolveReport = async (messageId) => {
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "resolve_report",
          messageId,
          adminUsername: username,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to resolve report");
      }

      await fetchModData();
    } catch (err) {
      console.error("Error resolving report:", err);
      setError("Failed to resolve report");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-lg w-96">
          <h1 className="text-2xl font-bold text-[#FF69B4] mb-6 text-center">
            Moderator Login
          </h1>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="username">
                Username
              </label>
              <input
                id="username"
                name="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                required
              />
            </div>
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#FF69B4]"
                required
              />
            </div>
            {error && (
              <div className="text-red-500 text-sm text-center">{error}</div>
            )}
            <button
              type="submit"
              className="w-full bg-[#FF69B4] text-white py-2 rounded hover:bg-[#FF1493] transition duration-200"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-gray-200">
        <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-[#FF69B4]">
            Moderation Dashboard
          </h1>
          <button
            onClick={() => setIsAuthenticated(false)}
            className="bg-[#FF69B4] text-white px-4 py-2 rounded hover:bg-[#FF1493]"
          >
            Logout
          </button>
        </nav>
      </header>

      <main className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="text-center text-gray-600">Loading...</div>
        ) : error ? (
          <div className="text-red-500 text-center">{error}</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-bold mb-4">Active Users</h2>
              <div className="space-y-2">
                {stats.users.map((user) => (
                  <div
                    key={user.username}
                    className="flex items-center justify-between p-2 bg-gray-50 rounded"
                  >
                    <span>{user.username}</span>
                    <span className="text-gray-600">
                      Messages: {user.message_count}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-bold mb-4">Active Rooms</h2>
              <div className="space-y-2">
                {stats.rooms.map((room) => (
                  <div
                    key={room.room_code}
                    className="flex items-center justify-between p-2 bg-gray-50 rounded"
                  >
                    <span>{room.room_code}</span>
                    <span className="text-gray-600">
                      Messages: {room.message_count}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-bold mb-4">Reported Messages</h2>
              <div className="space-y-2">
                {reportedMessages.map((report) => (
                  <div
                    key={report.message_id}
                    className="p-2 bg-gray-50 rounded space-y-2"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-medium">{report.username}</span>
                        <span className="text-gray-600 ml-2">
                          in {report.room_code}
                        </span>
                      </div>
                      <span className="text-gray-600 text-sm">
                        {new Date(report.reported_at).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-gray-800">{report.content}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 text-sm">
                        Reported by: {report.reported_by}
                      </span>
                      <div className="space-x-2">
                        <button
                          onClick={() => handleResolveReport(report.message_id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={() => banUser(report.username)}
                          className="text-red-500 hover:text-red-700"
                        >
                          Ban User
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {reportedMessages.length === 0 && (
                  <p className="text-gray-600 text-center">
                    No reported messages
                  </p>
                )}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-bold mb-4">Banned Users</h2>
              <div className="space-y-2">
                {bannedUsers.map((user) => (
                  <div
                    key={user.username}
                    className="flex items-center justify-between p-2 bg-gray-50 rounded"
                  >
                    <div>
                      <span className="font-medium">{user.username}</span>
                      <span className="text-gray-600 ml-2">
                        Banned: {new Date(user.banned_at).toLocaleString()}
                      </span>
                    </div>
                    <button
                      onClick={() => handleUnban(user.username)}
                      className="text-[#FF69B4] hover:text-[#FF1493]"
                    >
                      Unban
                    </button>
                  </div>
                ))}
                {bannedUsers.length === 0 && (
                  <p className="text-gray-600 text-center">No banned users</p>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default MainComponent;